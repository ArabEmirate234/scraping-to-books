class Categorie():

    def __init__(self, nom, url):
        self.nom = nom
        self.url = url


