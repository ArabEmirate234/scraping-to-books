class Livre():

    def __init__(self, titre, description, image, lien, prix, note):
        self.titre = titre